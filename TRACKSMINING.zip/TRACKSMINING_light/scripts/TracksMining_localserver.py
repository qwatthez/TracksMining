#######################################################################            
##################### TRACKSMINING VIEW ###############################
#######################################################################  

#! /usr/bin/python
# -*- coding:utf-8 -*-

from flask import Flask, request, redirect, render_template, url_for, session, send_file
from flask_caching import Cache
from flask_executor import Executor
from werkzeug.utils import secure_filename
from werkzeug.datastructures import  FileStorage
import datetime
import json
import pandas as pd
import sys
import re

import pandas as pd
import math

class FileScanner:
    """ A class to scan the file, check potential errors and prefill settings"""

    def __init__(self, filename):
        self.filename = filename
    
    def run(self):
        self.check_extension()
        self.set_path()
        self.read_data_from_csv()
        self.replace_comma_with_dot()
        self.check_minimal_columns()
        self.check_ID_column()
        self.check_if_multiple_animals()
        self.drop_NA_data()
        self.check_data_size()
        self.create_nlocs_warning()
        self.parse_time()
        self.chronological_sort()
        self.get_first_and_last_date()
        self.get_total_track_time()
        self.get_dop_values()
        self.get_geographical_limits()
        self.check_outliers()
        self.create_outliers_warning()
        self.check_location_interval()
    
    def check_extension(self):
        """Check the file is .txt, .csv or .xls"""
        print("Vérification de l'extension")
        valid_format = ['.txt', '.csv']
        self.file_format = self.filename[-4:]
        assert self.file_format in valid_format
    
    def set_path(self):
        self.path = f'../data/positions/{self.filename}'

    def read_data_from_csv(self):
        "Get a pandas dataframe from a raw file .TXT or .CSV"
        print('Lecture du fichier')
        self.data = pd.read_csv(self.path,
                    sep=None, #= Auto-detection of separator
                    engine='python',
                     )
    
    def check_ID_column(self):
        ID_values = ["ID", "Id", "id", "NAME", "Name", "name", "ANIMAL", "Animal", "animal"]
        self.animal_id = self.filename[:-4]#''
        for i in ID_values:
            if i in self.data.columns.values:
                self.identifiers = list(self.data[i].unique())
                self.animal_id = self.identifiers[0]
            else:
                self.identifiers = []
        print(self.identifiers)
    
    def check_if_multiple_animals(self):
        """Check if the input file has many animals"""
        self.animal_id_warning = ""
        if self.identifiers and len(self.identifiers)>1:
            self.animal_id_warning = """ Il semble que le jeu de données contient
                                         des données de plusieurs individus.  Ce type de suivi
                                         n'est pas encore possible avec la version actuelle de l'application"""
                

    def replace_comma_with_dot(self):
        for col in ['LAT','LON','DOP']:
            self.data[col] = self.data[col].astype(str)
            self.data[col] = self.data[col].str.replace(',','.')
            self.data[col] = self.data[col].astype(float)
    
    def check_minimal_columns(self):
        """Check if essential columns are in the file"""
        print('Vérification des colonnes minimales')
        columns_list=['TIME','LON','LAT','DOP'] #La DOP restera t-elle essentielle?
        for i in columns_list:
            if not i in self.data.columns.values:
                print('colonne manquante: ', i)
    
    def drop_NA_data(self):
        """Drop data with NA values"""
        print("Suppression des colonnes NA")
        self.data = self.data.dropna(subset = ['TIME', 'LAT', 'LON', 'DOP'])
    
    def check_data_size(self):
        """Count lines in the raw dataset (header excluded)"""
        print('Comptage du nombre de lignes')
        self.n_locations = len(self.data)
        print(f"Le fichier contient {self.n_locations} lignes de données")
    
    def create_nlocs_warning(self):
        self.nlocs_warning = ""
        self.filter_advice = ""
        self.filter_advice
        if self.n_locations > 10000:
            self.filter_advice = "(Conseillé)"
            self.nlocs_warning = f"""Le fichier comprend un grand nombre de données ({self.n_locations}).
                              Pour obtenir des performances optimales, il est recommandé
                              de filtrer sur une plus petite période temporelle (1 an maximum)."""
        if self.n_locations > 20000:
            self.filter_advice = "(Recommandé)"
            self.nlocs_warning = f"""Le fichier comprend un très grand nombre de données ({self.n_locations}).
                              Pour optimiser les performances de l'application, il est recommandé de filtrer
                              sur une plus petite période temporelle (1 an maximum)."""
        
    def parse_time(self):
        """Parse the TIME column to datetime object"""
        print("Formatage de la date")
        mapping=['%d/%m/%y %H:%M:%S',#biches SMF
                 '%d-%m-%y %H:%M:%S',#biches SMF
                 '%Y-%m-%d %H:%M:%S', #cerfs individuels
                 '%d/%m/%y %H:%M:%S %Z', #shoebills
                 '%d/%m/%Y %H:%M:%S %Z', #ratons
                 '%d/%m/%y %H:%M', # Sofia
                 '%d/%m/%Y %H:%M:%S', # blaireaux 3/4/2016 03:26
                 '%d/%m/%Y %H:%M:%S %Z'
                     ]
        
        def try_key(n):
            if n >= len(mapping):
                print("Clé de conversion pas trouvée")
            else:
                try:
                    self.data['TIME']=pd.to_datetime(self.data['TIME'], format= mapping[n])
                    self.time_format=mapping[n]
                    print(self.time_format)
                except ValueError:
                    try_key(n+1)
                    
        try_key(0)
    
    def chronological_sort(self):
        """Make sure data is well sorted out chronologically before any computing operation"""
        print("Tri chronologique des géolocalisations")
        self.data.sort_values(by = 'TIME', inplace = True)
        self.data = self.data.reset_index(drop=True)
    
    def get_first_and_last_date(self):
        """Check the first date and last date"""
        self.first_date = min(self.data['TIME']).date()
        self.last_date = max(self.data['TIME']).date()
        print(f"La première date disponible est le {self.first_date}")
        print(f"La dernière date disponible est le {self.last_date}")
    
    def get_total_track_time(self):
        self.total_track_time = self.last_date - self.first_date
        print(f"L'animal a été suivi sur une période de {self.total_track_time.days} jours")
    
    def get_dop_values(self):
        """Check the DOP mean"""
        self.mean_dop = self.data['DOP'].mean().round(1)
        self.max_dop = self.data['DOP'].max().round(1)
        self.median_dop = self.data['DOP'].median().round()
        self.p95_dop = self.data['DOP'].quantile(0.95).round()
        print(f"La DOP moyenne est {self.mean_dop}")
        print(f"La DOP maximum est {self.max_dop}")
        print(f"La DOP médiane est {self.median_dop}")
        print(f"Le p95 DOP est {self.p95_dop}")
 
    def get_geographical_limits(self):
        """Check the limit of the distribution"""
        self.north_limit = math.ceil(max(self.data['LAT'])*100)/100
        self.south_limit = math.floor(min(self.data['LAT'])*100)/100
        self.east_limit = math.ceil(max(self.data['LON'])*100)/100
        self.west_limit = math.floor(min(self.data['LON'])*100)/100
        print(f"La latitude est comprise entre {self.south_limit} et {self.north_limit}")
        print(f"La longitude est comprise entre {self.west_limit} et {self.east_limit}")
    
    def check_outliers(self):
        """Check the need for outliers management"""
        
        def get_outliers(column, threshold):
            q1 = self.data[column].quantile(0.25)
            q3 = self.data[column].quantile(0.75)
            IQR = (q3-q1)
            
            inf_border = q1-(IQR)*threshold
            sup_border = q3+(IQR)*threshold
            
            check1 = self.data[column]<inf_border
            check2 = self.data[column]>sup_border
            return check1 + check2
        
        threshold = 4
        #threshold = self.settings['outliers_IQR']
        
        lat_outsiders = get_outliers('LAT', threshold)
        lon_outsiders = get_outliers('LON', threshold)
        self.data['OUTLIER'] = lat_outsiders + lon_outsiders
        self.n_outliers = len(self.data[self.data['OUTLIER']== True])
        a = len(self.data[self.data['OUTLIER']== True])
        b = len(self.data[self.data['OUTLIER']== False])
        print(f"Identification de {self.n_outliers} géolocalisations potentiellement outliers")
        
        #Note, faire un test en ne gardant que les outliers et vérifier s'ils sont regroupés, spatialement ou dans le temps.
        # Cette approche permet d'identifier des clusters.
        # Ou alors utiliser les KMEANS?
        # Attention, qu'idéalement il faut travailler en données projetées
    
    def create_outliers_warning(self):
        """Create a notification if potential outliers are detected"""
        self.outliers_warning = """Une première analyse ne suggère pas la présence d'outliers"""
        if self.n_outliers > 0:
            self.outliers_warning = """Une première analyse suggère la présence de quelques localisations erronées"""
    
    def check_location_interval(self):
        """Check the best interval for animation"""
        self.data['TIME2'] = self.data['TIME'].shift(periods=1)
        diff = self.data['TIME']-self.data['TIME2']
        del(diff[0])
        diff = diff.round('H')
        mode = diff.mode()[0]
        mode = round(mode.total_seconds()/3600)

        for i in [1, 2, 4, 8, 12, 24, 48]:
            if mode<=i:
                self.mode_interval = i
                break
        print(f"L'intervalle de temps le plus adapté pour l'animation est de {self.mode_interval}h")



app = Flask(__name__) #Instanciation de l'objet
logger={}


@app.route('/', methods=['GET', 'POST'])
def start_tracking():
    
    if request.method == 'POST':
        # Mise en mémoire du nom du document
        logger['filename'] = get_filename('GPS_file')
        scan_file()        
        return redirect('/settings')
        
    html = get_template('../data/templates_html/TracksMining.html')
    return html

@app.route('/settings', methods=['GET', 'POST'])
def fill_settings():
    
    if request.method == 'POST':
        settings = get_settings(request.form)
        settings = fill_missing_fields(settings)
        settings['GPS_file'] = logger['filename']
        settings['interaction_file'] = get_filename('interaction_file')
        logger['settings']=settings
        print("Exécution du programme")

        launch_application(settings)
        return redirect('/download_finished')

    html = get_template('../data/templates_html/settings_interface.html')
    html = prefill_settings(html)
    return html


@app.route('/download_finished', methods=['GET'])
def step1():
    print('**************')
    path = get_directory_name(logger)
    return send_file(f'../output/{path}.zip', as_attachment=True, download_name=f"{path}.zip")

def get_template(template):
    with open(template, 'r') as file:
        html = file.readlines()
        html = "".join(html)
    print(f"Lecture du fichier html: {template}")
    return html

def prefill_settings(html):
    """Fill the template with informations scanned"""
    for i,j in logger.items():
        html = re.sub(i,str(j), html)
    return html
    
def get_filename(name):
    """Retrieve the GPS file"""
    data_file = request.files[name]
    filename = data_file.filename
    return filename

def scan_file():
    """Scan the file to check everything is OK to start analysis"""
    filename = logger['filename']
    scanner = FileScanner(filename)
    scanner.run()
    logger['#ANIMAL_ID'] = scanner.animal_id#.capitalize()
    logger['#ID_WARNING'] = scanner.animal_id_warning
    logger['#OUTLIER_WARNING'] = scanner.outliers_warning
    logger['#FIRST_DATE'] = scanner.first_date.strftime("%d/%m/%Y")
    logger['#MIN_DATE_LIMIT'] = scanner.first_date.strftime("%Y-%m-%d")
    logger['#LAST_DATE'] = scanner.last_date.strftime("%d/%m/%Y")
    logger['#MAX_DATE_LIMIT'] = scanner.last_date.strftime("%Y-%m-%d")
    logger['#N_LOCATIONS'] = scanner.n_locations
    logger['#FILTER_ADVICE'] = scanner.filter_advice
    logger['#NLOCS_WARNING'] = scanner.nlocs_warning
    logger['#TIME_FORMAT'] = scanner.time_format
    logger['#MEAN_DOP'] = scanner.mean_dop
    logger['#MAX_DOP'] = scanner.max_dop
    logger['#MEDIAN_DOP'] = scanner.median_dop
    logger['#P95_DOP'] = scanner.p95_dop
    logger['#NORTH_LIMIT'] = scanner.north_limit
    logger['#SOUTH_LIMIT'] = scanner.south_limit
    logger['#EAST_LIMIT'] = scanner.east_limit
    logger['#WEST_LIMIT'] = scanner.west_limit
    logger['#MODE_INTERVAL'] = scanner.mode_interval


def save_data(file):
    """Store the uploaded data in a folder on the server"""
    name = secure_filename(file.filename)
    path_to_file = f"..data/positions/{name}"
    file.save(path_to_file)
    return path_to_file


def launch_application(settings):
    from Tracksmining import TracksMining
    T = TracksMining(settings)
    T.run()
    #T.data.display_locations_columns()
    T.logger.display()
    T.settings.display()

def get_settings(form):
    """read settings directly from an html request"""
    print("Récupération des paramètres")

    settings_df = pd.DataFrame.from_dict(dict(form), orient='index',columns=['VALUE'])
    settings_df = settings_df.reset_index()
    settings_df.columns = ['PARAMETER','VALUE']
    
    settings_df['VALUE'] = settings_df['VALUE'].replace('on', True)
    settings_df['VALUE'] = settings_df['VALUE'].replace('off', False)
    settings_df['VALUE'] = settings_df['VALUE'].replace('', False)
    
    settings_df = settings_df.set_index('PARAMETER')
    settings_df = settings_df.T
    
    # Settings Integer values
    integer_columns = ['mcp_isopleth',
                       'kde_isopleth',
                       'kde_resolution',
                       'kde_bandwidth',
                       'locoh_k_value',
                       'locoh_isopleth',
                       'locoh_r_value',
                       'gridcell_resolution',
                       ]
    
    for col in integer_columns:
        settings_df[col] = settings_df[col].astype(int)
        
    # Settings Float values
    float_columns = ['south_limit',
                     'north_limit',
                     'west_limit',
                     'east_limit',
                     'min_dop']
    
    for col in float_columns:
        settings_df[col] = settings_df[col].astype(float)
    
    # Settings Datetime values
    date_columns = ['read_from_date',
                    'read_until_date',]

    for col in date_columns:
        if settings_df[col][0]:
            settings_df[col] = pd.to_datetime(settings_df[col], format='%Y-%m-%d')
    
    # Settings Time values
    time_columns = ['read_from_hour',
                    'read_until_hour',]
    for col in time_columns:
        if settings_df[col][0]:
            settings_df[col] = datetime.time.fromisoformat(settings_df[col][0])
        
    settings = settings_df.to_dict(orient = 'records')

    return settings[0]

def fill_missing_fields(settings):
    
    default_values={'filter_coords': False,
                    'filter_date': False,
                    'filter_time': False,
                    'filter_dop': False,
                    'circadian_mode':'Dawn/Dusk/Day/Night',
                    'outliers_management':'Ignorer',
                    'outliers_IQR': 3,
                    'add_locations': False,
                    'add_enveloppe': False,
                    'add_centroid': False,
                    'add_heatmap': False,
                    'add_tracks': False,
                    'add_kde': False,
                    'kde_full_range': False,
                    'kde_resolution': 100,
                    'kde_isopleth': 95,
                    'kde_bandwidth': 100,
                    'kde_auto_bandwidth': False,
                    'add_MCP': False,
                    'add_gridcell': False,
                    'add_animation': False,
                    'interaction_analysis': False,
                    'create_charts': False,
                    'add_locoh': False,
                    'locoh_isopleth':100,
                    'add_k_locoh': False,
                    'add_r_locoh': False,
                    'locoh_r_value': 100,
                    'locoh_k_value':10,
                    'tracks_color':'dimgrey',
                    'mouse_coords': False,
                    'mini_map': False,
                    'drawing_tool': False,
                    'erase_output_folder': False,
                    }
    
    settings = {**default_values, **settings}    
    return settings

def get_directory_name(logger):
    animal_name = logger['settings']['animal_name']
    start_date = logger['settings']['read_from_date'].strftime('%Y%m%d')
    stop_date = logger['settings']['read_until_date'].strftime('%Y%m%d')      
    directory_name = f"""{animal_name}_from_{start_date}_to_{stop_date}"""
    return directory_name
        
def save_settings(settings):
    print("Enregistrement des paramètres")
    with open('../data/settings/settings.txt', 'w') as file:
        file.write(json.dumps(settings))

if __name__ == '__main__':
    app.run(debug=True)
